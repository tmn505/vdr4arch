// ---------------------------------------------
// --- Name:    Easy DHTML Treeview           --
// --- Author:  D.D. de Kerf                  --
// --- Adapted: Markus Ehrnsperger            --
// --- Adapted: Jasmin Jessich                --
// --- Adapted: hepi (via patch)              --
// --- Adapted: Dieter Hametner               --
// --- Version: 0.3          Date: 14-6-2017  --
// ---------------------------------------------

function set_folder_closed(rec_list) {
  const fldr_hash = rec_list.id;
  uncheck_all(rec_list);
  updateCookieOnCollapse(fldr_hash);

  const folder_symbol_element=document.getElementById('fs_'+fldr_hash);
//folder_symbol_element.setAttribute("onClick", '');
  set_icons_closed(document.getElementById('pm_'+fldr_hash), folder_symbol_element);
  if (folder_symbol_element.$tmp) folder_symbol_element.$tmp.myText=null;

//document.getElementById('ca_'+fldr_hash).disabled = true;
  rec_list.style.display = 'none';
}
async function set_folder_open(rec_list) {
// return true in case of a dom change
  const fldr_hash = rec_list.id;
  updateCookieOnExpand(fldr_hash);

  var dom_changed = false;

  const rec_id = rec_ids[fldr_hash];
  if (rec_id != null && rec_id.length >= 3 && rec_id[1] != 2) {
    rec_id[1] = 2;
    dom_changed = true;
    const to_insert=await rec_string_d_a(rec_id, fldr_hash);
    rec_list.insertAdjacentHTML("beforeend", to_insert);
  }

  const folder_symbol_element=document.getElementById('fs_'+fldr_hash);
//folder_symbol_element.setAttribute( "onClick", 'javascript: SetChecked("'+fldr_hash+'")');
  set_icons_open(document.getElementById('pm_'+fldr_hash), folder_symbol_element);
//if (folder_symbol_element.$tmp==null) {
//  folder_symbol_element.title=get_text_Select_all_recordings_in_this_folder();
//} else {
//  folder_symbol_element.$tmp.myText=get_text_Select_all_recordings_in_this_folder();
//}

//document.getElementById('ca_'+fldr_hash).disabled = false;
  rec_list.style.display = 'revert-layer';
  return dom_changed;
}

function SetCheckboxValues(fldr_hash, value) {
//document.getElementById('ca_'+fldr_hash).checked = value;

  if (rec_ids[fldr_hash] == null || rec_ids[fldr_hash].length < 3) return;
  for (var item of rec_ids[fldr_hash][2]) {
    const cb=document.getElementById("cb_"+fldr_hash+"_"+item);
    if (cb != null) cb.checked=value;
  }
}
function uncheck_all(rec_list)
{
  SetCheckboxValues(rec_list.id, false);
  for (var recordingNode of rec_list.getElementsByClassName("recordingslist") ) {
    SetCheckboxValues(recordingNode.id, false);
  }
}

async function click_folder_line (e, fldr_hash) {
//alert('click_folder_line, currentTarget='+e.currentTarget.id+' target='+e.target.id+' fldr_hash='+fldr_hash);
//alert('click_folder_line, target='+e.target.id+' fldr_hash='+fldr_hash);

  const rec_list = document.getElementById(fldr_hash);
  if (rec_list == null) return;

  if ('sa_'+fldr_hash == e.target.id) {
// click on folder select all symbol
    if (rec_list.style.display != 'none') SetCheckboxValues(fldr_hash, true);
  } else if ('ds_'+fldr_hash == e.target.id) {
// click on folder de-select all symbol
    SetCheckboxValues(fldr_hash, false);
  } else if (rec_list.style.display == 'none') {
    if (await set_folder_open(rec_list) ) {
      if (typeof liveEnhanced !== 'undefined') liveEnhanced.domReadySetup();
      imgLoad();
    }
  } else {
// Collapse the branch if it IS visible
      set_folder_closed(rec_list);
  }
}
async function Toggle(node, fldr_hash) {
// Unfold the branch if it isn't visible
  alert("Toggle, fldr_hash="+fldr_hash);
  const rec_list = document.getElementById(fldr_hash);
  if (rec_list == null) return;

  if (rec_list.style.display == 'none') {
    if (await set_folder_open(rec_list) ) {
      if (typeof liveEnhanced !== 'undefined') liveEnhanced.domReadySetup();
      imgLoad();
    }
  } else {
// Collapse the branch if it IS visible
    set_folder_closed(rec_list);
  }
}
function ToggleChecked(node, fldr_hash) {
// If unchecked,   check all items.
// If   checked, uncheck all items.
  const rec_list = document.getElementById(fldr_hash);
  if (rec_list == null) return;

  if (rec_list.style.display == 'none') return;
  SetCheckboxValues(fldr_hash, node.checked);
}

function SetChecked(fldr_hash) {
// check all items.
  const rec_list = document.getElementById(fldr_hash);
  if (rec_list == null) return;

  if (rec_list.style.display == 'none') return;
  SetCheckboxValues(fldr_hash, true);
}

function saveSelection(form)
{
  let checkboxes = [];
  for (const input of form?.getElementsByTagName('input') ?? []) {
    if (input.type == 'checkbox' && input.checked) {
      checkboxes.push(input.id);
    }
  }
  if (checkboxes.length > 0) {
    createCookie(cookieNameSelection, checkboxes.join(','), 1);
  } else {
    clearSavedSelection();
  }
}

function restoreSelection()
{
  clearCheckboxes(document.getElementById('form_recordings'));
  const cookie = readCookie(cookieNameSelection);
  for (const id of cookie?.split(',') ?? []) {
    const fldr_hash = id.split('_')[1];
    const input = document.getElementById(id);
    if (input?.type == 'checkbox') {
      input.checked = true;
    }
  }
}

function clearSavedSelection()
{
  eraseCookie(cookieNameSelection);
}

function updateCookieOnExpand( id )
{
  var openNodes = readCookie(cookieNameOpenNodes);
  if (openNodes == null || openNodes == "")
    openNodes = id;
  else {
    for (var openNode of openNodes.split(",")) {
      if (openNode === id) return;
    }
    openNodes += "," + id;
  }
  createCookie(cookieNameOpenNodes, openNodes, 14);
}

function updateCookieOnCollapse(id)
{
let openNodes = readCookie(cookieNameOpenNodes);
if (openNodes != null)
  openNodes = openNodes.split(",");
else
  openNodes = [];
for (var z=0; z<openNodes.length; z++) {
  if (openNodes[z] === id){
    openNodes.splice(z,1);
    break;
  }
}
openNodes = openNodes.join(",");
createCookie(cookieNameOpenNodes, openNodes, 14);
}

async function openNodesOnPageLoad()
{
  let openNodes = readCookie(cookieNameOpenNodes);
  if (openNodes != null && openNodes !== "")
    openNodes = openNodes.split(",");
  else
    openNodes = [];
  let domChanges = 0;
  for (var openNode of openNodes) {
    const rec_id = rec_ids[openNode];
//  if (!openNode) continue;  // otherwise throws error for level 0
    const rec_list = document.getElementById(openNode);
    if (rec_list == null) continue;
    if (await set_folder_open(rec_list) ) domChanges = 1;
  }
  if (domChanges == 1 && typeof liveEnhanced !== 'undefined') liveEnhanced.domReadySetup();
  for (var openNode of openNodes) {
    const rec_id = rec_ids[openNode];
  }
}

function getElementsByNodeNameClassName(elementd, nodeName, className) {
// example: getElementsByNodeNameClassName(window.document, 'DIV', 'test')
const classElements = elementd.getElementsByClassName(className);
  return Array.prototype.filter.call(
    classElements, (classElement) => classElement.nodeName === nodeName,
  );
}

function filterRecordings(filter, currentSort, currentFlat, recycle_bin)
{
  window.location.href = "recordings.html?sort=" + currentSort + "&flat=" + currentFlat + "&filter=" + encodeURIComponent(filter.value) + "&recycle_bin=" + recycle_bin;
}
function deletedRecordings(recycle_bin, currentSort, currentFlat, currentFilter)
{
  if (recycle_bin.checked) {
    window.location.href = "recordings.html?sort=" + currentSort + "&flat=" + currentFlat + "&filter=" + currentFilter + "&recycle_bin=1";
  } else {
    window.location.href = "recordings.html?sort=" + currentSort + "&flat=" + currentFlat + "&filter=" + currentFilter + "&recycle_bin=0";
  }
}

async function ExpandAll()
{
  var domChanges = 0;
  recordingNodes = getElementsByNodeNameClassName(window.document, 'UL', "recordingslist");
  for (idx = 0; idx < recordingNodes.length; idx++) {
    if (recordingNodes[idx].parentNode.className != 'recordings') {
      if (await set_folder_open(recordingNodes[idx]) ) domChanges = 1;
    }
  }
  if (domChanges == 1 && typeof liveEnhanced !== 'undefined') liveEnhanced.domReadySetup();
  if (domChanges == 1) imgLoad();
}
function CollapseAll()
{
  recordingNodes = getElementsByNodeNameClassName(window.document, 'UL', "recordingslist");
  for (idx = 0; idx < recordingNodes.length; idx++) {
    if (recordingNodes[idx].parentNode.className != 'recordings') {
      set_folder_closed(recordingNodes[idx]);
    }
  }
  eraseCookie( cookieNameOpenNodes );
}

const cookieNamePrefix = "VDR-Live-Recordings-Tree";
const cookieNameOpenNodes = cookieNamePrefix + "-Open-Nodes";
const cookieNameSelection = cookieNamePrefix + "-Selection";

async function DOMContentLoaded_() {
  await openNodesOnPageLoad();
  restoreSelection();
  restoreScrollPosition();
  imgLoad();
}
document.addEventListener("DOMContentLoaded", DOMContentLoaded_);


//The following cookie functions have evolved from the examples of http://www.quirksmode.org/js/cookies.html
function createCookie(name, value, days)
{
  const scope = "; SameSite=Lax; path=/"
  var expiration = "";   // defaults to session cookie
  if (days > 0) {
    // cookie with expiration time
    let date = new Date();
    date.setTime(date.getTime() + days * 24*60*60*1000);
    expiration = "; expires=" + date.toGMTString();
  } else if (days < 0) {
    // already expired cookie, i.e., cookie to be deleted
    let date = new Date(0);
    expiration = "; expires=" + date.toGMTString();
  }
  var cookie = name + "=" + value + expiration + scope;
  if (cookie.length >= 4096 ) {
    // oversized cookie deleted to avoid truncation issues
    let date = new Date(0);
    expiration = "; expires=" + date.toGMTString();
    cookie = name + "=" + expiration + scope;
  }
  document.cookie = cookie;
}

function readCookie(name)
{
  var nameEQ = name + "=";
  for (let c of document.cookie.split(';')) {
    c = c.trim();
    if (c.startsWith(nameEQ)) return c.substring(nameEQ.length);
  }
  return null;
}

function eraseCookie(name)
{
  createCookie(name, "", -1);
}
