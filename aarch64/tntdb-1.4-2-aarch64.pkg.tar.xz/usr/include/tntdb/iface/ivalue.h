/*
 * Copyright (C) 2005 Tommi Maekitalo
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * As a special exception, you may use this file as part of a free
 * software library without restriction. Specifically, if other files
 * instantiate templates or use macros or inline functions from this
 * file, or you compile this file and link it with other files to
 * produce an executable, this file does not by itself cause the
 * resulting executable to be covered by the GNU General Public
 * License. This exception does not however invalidate any other
 * reasons why the executable file might be covered by the GNU Library
 * General Public License.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#ifndef TNTDB_IFACE_IVALUE_H
#define TNTDB_IFACE_IVALUE_H

#include <cxxtools/refcounted.h>
#include <cxxtools/string.h>
#include <string>
#include <stdint.h>

namespace tntdb
{
  class Date;
  class Time;
  class Datetime;
  class Decimal;
  class Blob;

  /// common inteface for resultvalues
  class IValue : public cxxtools::RefCounted
  {
    public:
      virtual bool isNull() const = 0;
      virtual bool getBool() const = 0;
      virtual short getShort() const = 0;
      virtual int getInt() const = 0;
      virtual long getLong() const = 0;
      virtual unsigned getUnsigned() const = 0;
      virtual unsigned short getUnsignedShort() const = 0;
      virtual unsigned long getUnsignedLong() const = 0;
      virtual int32_t getInt32() const = 0;
      virtual uint32_t getUnsigned32() const = 0;
      virtual int64_t getInt64() const = 0;
      virtual uint64_t getUnsigned64() const = 0;
      virtual Decimal getDecimal() const = 0;
      virtual float getFloat() const = 0;
      virtual double getDouble() const = 0;
      virtual char getChar() const = 0;
      virtual void getString(std::string& ret) const = 0;
      virtual void getBlob(Blob& ret) const = 0;
      virtual Date getDate() const = 0;
      virtual Time getTime() const = 0;
      virtual Datetime getDatetime() const = 0;
      virtual void getUString(cxxtools::String& ret) const;
  };
}

#endif // TNTDB_IFACE_IVALUE_H

