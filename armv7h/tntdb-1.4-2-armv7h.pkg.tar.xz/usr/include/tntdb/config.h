/** defines, whether type long long exists */
#define HAVE_LONG_LONG

/** defines, whether type unsigned long long exists */
#define HAVE_UNSIGNED_LONG_LONG

/* define if int and int32_t are same types */
#define INT_INT32_T_CONFLICT 1

/* define if int and int64_t are same types */
#define INT_INT64_T_CONFLICT 0

/* define if unsigned and uint32_t are same types */
#define UNSIGNED_UINT32_T_CONFLICT 1

/* define if unsigned and uint64_t are same types */
#define UNSIGNED_UINT64_T_CONFLICT 0

