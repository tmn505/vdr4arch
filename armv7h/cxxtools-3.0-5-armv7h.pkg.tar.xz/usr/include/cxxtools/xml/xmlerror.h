/*
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * As a special exception, you may use this file as part of a free
 * software library without restriction. Specifically, if other files
 * instantiate templates or use macros or inline functions from this
 * file, or you compile this file and link it with other files to
 * produce an executable, this file does not by itself cause the
 * resulting executable to be covered by the GNU General Public
 * License. This exception does not however invalidate any other
 * reasons why the executable file might be covered by the GNU Library
 * General Public License.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */
#ifndef cxxtools_Xml_XmlError_h
#define cxxtools_Xml_XmlError_h

#include <stdexcept>

namespace cxxtools {

namespace xml {

//! Exception that is thrown when a parse error occured.
class XmlError : public std::runtime_error
{
    public:
        /**
            * @brief Creates a new ParseError object using the given reason and source info.
            *
            * @param what The reason of the parse error.
            * @param info Source info containing information about where the exception occured.
            */
        XmlError(const std::string& what, unsigned line);

        unsigned line() const
        { return _line; }

    private:
        unsigned _line;
};

/// Exception is thrown when trying to read a xml document but nothing was read.
///
/// It may not be really an error but just eof when no document is read at all.
class XmlNoDocument : public XmlError
{
    public:
        explicit XmlNoDocument(unsigned line)
            : XmlError("no xml document read", line)
        { }
};

/// Exception is thrown when trying to read a xml document but the underlying stream fails.
///
/// It is really an error if a document is just partly read.
class XmlUnexpectedEndOfDocument : public XmlError
{
    public:
        explicit XmlUnexpectedEndOfDocument(unsigned line)
            : XmlError("unexpected end of xml", line)
        { }
};

}

}

#endif
